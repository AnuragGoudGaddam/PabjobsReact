import React from 'react';

const LoginBody= () =>{
    return(
<div className="p-4 loginForm  d-flex flex-row">
<div className="row ">
    <div className="col-12 col-md-1"></div>
    <div className=" col-12 col-md-6 bodySide ">


        <div className="labels1">
            <div className=" maincard">
                <div className=" maincard1">
                    <h1 className="container2heading">Create an account</h1>
                    <p className="container2para">it only takes a couple of minutes to get started!</p>
                    <div className="d-flex flex-row justify-content-center row  ">
                        <div className="col-12 col-md-5">
                            <a href="project1Login.html"> <button className=" shadow form-control w-100  " id=""
                                    onclick="">Login <i className="fa-solid fa-circle-check" id=""></i></button></a>
                        </div>
                        <div className=" col-12 col-md-5">
                            <button className=" shadow form-control jan1 " id="" onclick="">Signup <i
                                    className="fa-solid fa-circle-check  "></i></button>
                        </div>

                    </div>
                    <div className="d-flex flex-row justify-content-center container2button row">
                        <div className=" col-12 col-md-5">
                            <button className="button1 shadow form-control" id="taskButton"
                                onclick="taskButton()">Job seekers
                                <input type="radio" id="icon1" className="jan"/></button>
                        </div>

                        <div class="col-12 col-md-5">
                            <button className="button2 shadow form-control" id="taskButton2"
                                onclick="taskButton2()">Recruiters
                                <input type="radio" name="" id="icon2" class="jan"/> </button>
                        </div>
                    </div>


                    <label className="label1" id="fullname">Full Name</label><br/>
                    <input className="inputs form-control" type="text" placeholder="Enter your full name"/><br/>
                    <label className="label1">Email ID</label><br/>
                    <input className="inputs form-control" type="email" placeholder="Enter your Emailid"/><br/>
                    <label className="label1">Passsword</label><br/>
                    <input className="inputs form-control" type="text" placeholder="Minimum 8 Characters"/><br/>
                    <label className="label1">Mobile Number</label><br/>
                    <p style={{color: "#270d44", fontWeight: "bold"}}>Mobile Number</p>
                    <div className="d-flex flex-row">
                        <select style={{color:"#270d44", borderRadius: "10px"}} className="">
                            <option  className="countryCode" style={{color: "#270d44", padding: "10px"}} id="+91">+91
                            </option>
                            <option className="countryCode" id="+46">+46</option>
                            <option className="countryCode" id="+54">+54</option>
                            <option className="countryCode" id="+99">+99</option>
                        </select>

                        <input className="inputs1 form-control  " type="text" placeholder="Enter your Mobile number"
                            id="otp1" onclick="otp1()"/>
                    </div>
                    <div className="Gender1">
                        <p style={{marginTop: "10px"}} id="genpact7">Gender</p>
                        <span style={{marginRight: "15px"}} ><input type="radio" id="genpact1"/><label
                                id="genpact2">Male</label></span>
                        <span style={{marginRight: "15px"}}> <input type="radio" id="genpact3"/><label
                                id="genpact4">Female</label> </span>
                        <span style={{marginRight: "15px"}}> <input type="radio" id="genpact5"/><label
                                id="genpact6">Prefex
                                not to say</label></span>
                    </div>
                    <i className="fa-solid fa-square-check icon"></i><label>I would like to get latest job
                        updates
                        on
                        Whatsapp.</label>
                    <p className="p">By clicking register,you agree to the terms and Conditions & Privacy Policy
                        of
                        PabJobs.com </p>
                    <button className="regButton">Register Now</button>


                </div>
            </div>
        </div>
    </div>


    <div class=" col-md-3 p-1 imageDiv d-none d-md-block ">
        <div class="row">
            <div> <img id="image1"
                    src="https://img.freepik.com/free-vector/computer-login-concept-illustration_114360-7962.jpg?w=2000"
                    width="300px" height="300" style={{borderRadius:"10px"}}/> </div>
            <div className="col-12">
                <div className="e d-flex flex-row"> <i style={{marginTop:" 2px"}}
                        className="fa-solid fa-circle-check"></i>
                    <p style={{marginLeft:" 20px"}}>Build your profile and let recutries find you
                    </p>
                </div>
                <div className="e d-flex flex-row"><i  style={{marginTop:" 2px"}} className="fa-solid fa-circle-check"></i>
                    <p style={{marginLeft:" 20px"}}>Get job posting deliverd right to your email</p>
                </div>
                <div className="e d-flex flex-row"> <i  style={{marginTop:" 2px"}}
                        className="fa-solid fa-circle-check"></i>
                    <p style={{marginLeft:" 20px"}}>Find a job and grow your career</p>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
)
}

export default LoginBody;
