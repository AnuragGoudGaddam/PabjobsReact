import logo from './logo.svg';
import './App.css';
import { ReactDOM } from 'react';
import Footer from './footer';
import { Routes,Route } from 'react-router-dom';
import Header from './headder';
import LoginBody from './Loginbody';

function App() {
  return (

    <div className="App">
      <Header/>
      {/* <Routes>
      <Route exact path='./login' > </Route>
      </Routes> */}
      <LoginBody/>
      < Footer />
    </div>
  );
}

export default App;
