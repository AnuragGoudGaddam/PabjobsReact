import React from 'react';

const Header = () => {
    return (
        <div className="container-fluid shadow" >
            <div className="row">
                <div className="col-md-2"></div>
                <div className="col-12 col-md-9">
                    <nav class="navbar navbar-expand-sm ">
                        <div class="container-fluid " id="navBar">
                            <a class="navbar-brand" href="#"><img src="https://play-lh.googleusercontent.com/73eFZhQXdDIiomGikoBpa-XZZf9-_1gkxrpoTFDZ0XzGMzEP0jcR09CC0Ma7UwSwgeDN=w240-h480-rw" width="150px" height="60px" /></a>
                            <div> <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapsibleNavbar">
                                <span className="navbar-toggler-icon"></span>
                            </button></div>

                            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                                <div style={{marginLeft: "30px"}}>
                                    <ul className="navbar-nav" style={{ fontWeight: "800", color: "#270d44" }}>
                                        <li className="nav-item">
                                            <a className="nav-link" href="homePabJobs.html" style={{ fontWeight: "bold " }}>Home</a>
                                        </li>
                                    </ul>
                                </div>
                                <div style={{marginLeft: "30px"}} >
                                    <ul className="navbar-nav" style={{ fontWeight: "500", color: "#270d44" }}>
                                        <li className="nav-item">
                                            <a className="nav-link" href="browseJobs.html" style={{ fontWeight: "bold " }}>Browse Jobs  <i class="fa-solid fa-caret-down"></i> </a>
                                        </li>
                                    </ul>
                                </div>

                                <div style={{marginLeft: "30px"}}>
                                    <ul className="navbar-nav" style={{ fontWeight: "500", color: "#270d44" }}>
                                        <li className="nav-item">
                                            <a className="nav-link" href="JobsPab.html" style={{ fontWeight: "bold " }}>Jobs <i class="fa-solid fa-caret-down"></i></a>
                                        </li>
                                    </ul>
                                </div>

                                <div style={{marginLeft: "30px"}}>
                                    <ul className="navbar-nav" style={{ fontWeight: "500", color: "#270d44" }}>
                                        <li className="nav-item">
                                            <a className="nav-link" style={{ fontWeight: "bold " }}>Services <i class="fa-solid fa-caret-down"></i></a>
                                        </li>
                                    </ul>
                                </div>
                                <div style={{marginLeft: "30px"}}>
                                    <ul className="navbar-nav" style={{ fontWeight: "500", color: "#270d44" }}>
                                        <li className="nav-item">
                                            <a className="nav-link" href="PaymentPab.html" style={{ fontWeight: "bold " }}>Payments <i class="fa-solid fa-caret-down"></i></a>
                                        </li>
                                    </ul>
                                </div>
                                <div> <i className="fa-regular fa-bell"
                                    style={{ fontSize: "xx-large", marginLeft: "20px", color: "#270d44" }}></i></div>
                                <div style={{ marginLeft: "20px", fontSize: "xx-large", color: " #270d44" }}> <i
                                    className="fa-sharp fa-solid fa-circle-user"></i>
                                    <i className="fa-solid fa-caret-down"></i>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    )
}

export default Header;