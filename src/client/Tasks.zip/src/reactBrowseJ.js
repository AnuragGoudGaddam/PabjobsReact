import { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';
import Header from "./headder";
import Footer from "./footer";


function BrowseJObs() {
    const [blogslist, setblogslist] = useState([]);
    const [BrowseJObsBlog, setBrowseJObsBlog] = useState(null);

    useEffect(() => {
        fetchblogs()
    }, [])

    const fetchblogs = async () => {
        const api = "https://pab-server.onrender.com/api/jobs";
        const authToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NGNiNzQ4Y2RkODQzZGIzNjk0M2NjM2EiLCJpYXQiOjE2OTExNDY4ODR9.8pVTqWMueERXuA6OCy1yNtl0GUbBHinGzcTpd59H7fk';
        try {
            const response = await axios.get(api, {
                headers: {
                    Authorization: `Bearer ${authToken}`
                }
            });
            setblogslist(response.data);
        } catch (error) {
            console.error("Error fetching blogs:", error);
        }
    };



    const onclickblogdetails = async (blogid) => {
        const selectedJobDetails = blogslist.find((each) => each._id === blogid)
        console.log(selectedJobDetails)
        setBrowseJObsBlog(selectedJobDetails)




    }

    console.log(blogslist)
    console.log(BrowseJObsBlog);




    return (
        <div>
            <Header />
            <div className="container mt-1 ">
                <div className="row">

                    <div class="col-12  first  ">
                        <div class="col-md-4"></div>
                        <div class="row">
                            <div class="col-5"> </div>
                            <div class="col-2">
                                <p>Home <span>{">"}</span> Jobs</p>
                            </div>
                            <div class="col-4"> </div>
                        </div>
                        <div class="input-group mb-3 p-2">
                            <div className='col-2 m-2'></div>

                            <div className="col-md-4 col-12 d-flex flex-row m-3 "
                                style={{ backgroundColor: 'white', height: '40px', width: '320px', borderRadius: '10px', marginLeft: '150px' }}>
                                <span class="px-1 mt-1"> <i class="fa-solid fa-location-dot"></i> </span>
                                <span class="px-5 mt-1 "><input class="w-100 dropdown-toggle"
                                    style={{ border: 'none', fontSize: ' small', width: '250px' }} type="text"
                                    placeholder="job Title, Skills or company " /></span>
                                <span class="px-3"> <i class="fa-solid fa-caret-down"></i></span>
                            </div>
                            <div class="col-md-4 col-12 d-flex flex-row   m-3"
                                style={{ backgroundColor: 'white', height: '40px', width: '320px', borderRadius: '10px', marginLeft: '150px' }}>
                                <span class="px-1 mt-1"> <i class="fa-solid fa-location-dot"></i> </span>
                                <span class="px-5 mt-1 "><input class="w-100 dropdown-toggle"
                                    style={{ border: 'none', fontSize: ' small', width: '250px' }} type="text"
                                    placeholder="job Title, Skills or company " /></span>
                                <span class="px-3"> <i class="fa-solid fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class="row m-3">
                            <div class="col-5 "> </div>
                            <div class="col-5 w-50">
                                <button style={{ backgroundColor: '#270d44', borderRadius: '5px', color: '#ffff', marginLeft: '50px' }}>Search</button>
                            </div>
                            <div class="col-4"> </div>
                        </div>
                    </div>
                    <div class="container mt-3">
                        <div class="row">
                            <div class="col-md-1"></div>
                            <div class="  col-10">
                                <div class="row ">


                                    <div class="col-md-2 ">
                                        <button class="btn dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#demo1" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' }}>Experiece</button>
                                        <div id="demo1" class="collapse card">
                                            <p>0-1 years</p>
                                            <p>2-3 years</p>
                                            <p>3-4 years</p>
                                            <p>4-5 years</p>
                                            <p>5-6 years</p>

                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#demo2" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' }}>Location</button>
                                        <div id="demo2" class="collapse card">
                                            <p>Hyderabad</p>
                                            <p>Banglore</p>
                                            <p>Chennai</p>
                                            <p>Mumbai</p>
                                            <p>Pune</p>
                                            <p>Gurgav</p>

                                        </div>
                                    </div>
                                    <div class="col-md-1 " >
                                        <button class=" dropdown-toggle btn" data-bs-toggle="collapse" data-bs-target="#demo3" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' ,marginLeft:'-20px' }}>Salary</button>
                                        <div id="demo3" class="collapse card">
                                            <p>2-4 LPA</p>
                                            <p>4-5 LPA</p>
                                            <p>6-7 LPA</p>
                                            <p>7-8 LPA</p>
                                            <p>8-9 LPA</p>
                                            <p>10-12 LPA</p>

                                        </div>
                                    </div>


                                    <div class="col-md-2">
                                        <button class="btn dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#demo4" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' }}>Industry</button>
                                        <div id="demo4" class="collapse card">
                                            <p>Software</p>
                                            <p>AI</p>
                                            <p>Data Science</p>
                                            <p>AWS</p>
                                            <p>SQL</p>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                    <button class="btn dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#demo5" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' ,marginLeft:'-15px' }}>Designation</button>
                                             <div id="demo5" class="collapse card">
                                            <p>Jr Developer</p>
                                            <p>Sr Developer</p>
                                            <p>HR</p>
                                            <p>MAnager</p>
                                            <p>CEO</p>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                    <button class="btn dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#demo6" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' }}>Education</button>
                                        <div id="demo6" class="collapse card">
                                            <p>B-tech</p>
                                            <p>MBA</p>
                                            <p>M-Tech</p>
                                            <p>Degree</p>
                                            <p>Agriculture</p>
                                        </div>
                                    </div>
                                    <div class="col-md-1">
                                    <button class="btn dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#demo7" type="button"
                                            style={{ color: '#270d44', backgroundColor: '#f8f2f8', fontSize: 'small', border: '1px solid black' }}>Skills</button>
                                     <div id="demo7" class="collapse card">
                                            <p>JAVA</p>
                                            <p>.Net</p>
                                            <p>MERN</p>
                                            <p>Python</p>
                                            <p>C++</p>
                                        </div>
                                    </div>
                                </div>
                                <p style={{ fontSize: 'small', color: ' gray', marginTop: '20px' }}>Showing 69 results for 'Graphic Designing'</p>
                            </div>
                            <div className='col-1'></div>
                        </div>
                    </div>

                    {/* <div class=" col-md-2"> </div> */}
                    <div className='col-1'></div>
                    <ul className="col-12 col-md-4 ">
                        {blogslist.map((blog) =>
                            <div className={` card mt-3 select ${BrowseJObsBlog && BrowseJObsBlog.id === blog._id ? "selected" : ''}`}
                                onClick={((e) => onclickblogdetails(blog._id))}>

                                <div className='row'>
                                    <div className='col-8'>
                                        <h4 style={{ fontSize: 'small' }}>{blog.title}</h4>
                                    </div>

                                    <div className='col-4'>


                                        <p>{blog.salary}</p>


                                    </div>
                                </div>

                                <div className=''>
                                    <p>{blog.jobType}</p>
                                    <p>{blog.cities}</p>
                                    <p>{blog.experience}</p>


                                </div>
                                <p style={{ textAlign: 'end', fontSize: 'x-small' }}>published One Day Ago</p>

                            </div>
                        )}
                    </ul>


                    <div className='col-md-6 mt-3 card  secondCard'  >
                        {BrowseJObsBlog &&
                            <div className='card mt-3 mb-2'>
                                <div className='row'>
                                    <div className='col-5 m-4 d-flex flex-row' style={{ borderRight: '2px solid #f8f2f8' }} >
                                        <div>
                                            <img src={BrowseJObsBlog.recruiter.profileImage} width={'30px'} />
                                        </div>
                                        <div>
                                            <h5>{BrowseJObsBlog.title}</h5>
                                            <p>{BrowseJObsBlog.recruiter.companyname}</p>
                                            <p style={{ fontSize: 'small' }} >Show more jobs in this company</p>
                                            <div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* <div className=''>
                                <span style={{ borderRight: '1px solid black',margin:'10px' ,height:'250px'}}></span>
                             </div> */}
                                    <div className='col-5' style={{ margin: '10px' }}>
                                        <p>{BrowseJObsBlog.salary}</p>
                                        <p>{BrowseJObsBlog.cities}</p>
                                        <p>{BrowseJObsBlog.experience}</p>

                                    </div>
                                </div>
                                <hr></hr>

                                <div className='row'>
                                    <div className='col-5 m-2'>
                                        <p>Posted Few Hours Ago</p>
                                        <p>Max position:{BrowseJObsBlog.maxPositions}</p>
                                        <p>Number Of Applicants:{BrowseJObsBlog.activeApplications}</p>
                                    </div>
                                    <div className='col-5 mt-2'>
                                        <button className='btn form-control' style={{ backgroundColor: '#270d44', color: 'white' }}>Apply Now</button>
                                    </div>
                                </div>
                                <div class="card p-2 m-2">
                                    <h5 style={{ color: "#270d44", fontSize: " small" }}> Job Desciption</h5>
                                    <h6 class="" style={{ color: "#270d44", fontSize: " small" }}> Roles and Responsibilites</h6>
                                    <p style={{ color: "#270d44", fontSize: " small" }}>
                                        Planning concepts by studying relevent information and materials <br></br> Illustrating concepts by
                                        designing examples of an assignmrnt size,type size and style and <br></br> submitting them for
                                        approval<br></br>
                                        Creting a wide range of graphics and layouts for products ,company logos <br></br> socal media
                                        banners, artwork and websits with software such as photologo.<br></br>
                                        Creating new graphics for socal media ,Email mailing Broadcasts lables & stickers for <br></br>
                                        products. Catogery ,etc .using adobe tools like photo shop ,illustarrtion and design <br></br>
                                        constructing with network, web design ,markting ,paintings and configure as necessary .<br></br>
                                        products. Catogery ,etc .using adobe tools like photo shop ,illustarrtion and design<br></br>
                                        rewiving the layouts and suggesitions and suggesting imporvements wirh necessary.
                                    </p>
                                    <h5 style={{ color: "#270d44", fontSize: " small" }}> Skills and Responsibilites:</h5>
                                    <p style={{ color: "#270d44", fontSize: " small" }}>
                                        Experience as a graphic designer or in a reational field.<br></br> Demostriate graphic skills witha
                                        strong portfolio.<br />
                                        Proficiency with require desktop publishing tools ,including Photoshop is desingn and <br></br>
                                        lillustrate <br></br>
                                        A strong eye for visual compsition . <br></br> Effective time management skills and ability to meet
                                        deadlines,<br></br>
                                        Able to give and recive construction crision<br></br> iciency with require desktop publishing tools
                                        ,including Photoshop is desingn
                                    </p>

                                </div>


                            </div>


                        }
                    </div>

                </div>
            </div >
            <Footer />
        </div>


    )
                    }
export default BrowseJObs;