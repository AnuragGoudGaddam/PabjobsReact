// import React from "react";

import { redirect } from "react-router-dom";
import { Button } from "react-bootstrap";

const JobCards12 = () => {
    return (
        <div>
            <div class="container jobDetails" id="jobDetails" >
                <div class="row p-2">
                    {/* <div class="col-md-2"></div> */}
                    <div class="col-md-2"></div>


                    <div class="col-md-6 col-12">
                        <div class="row m-1" style={{ textAlign: "center" }}>

                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>A</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>B</button>
                            </div>

                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>C</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>D</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>E</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>F</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>G</button>
                            </div>


                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>H</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>I</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>J</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>K</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>L</button>
                            </div>

                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>M</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>N</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>O</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>P</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>Q</button>
                            </div>

                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>R</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>S</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>T</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>U</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>V</button>
                            </div>
                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>W</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>X</button>
                            </div>

                            <div class="col-md-1 ">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>Y</button>
                            </div>
                            <div class="col-md-1">
                                <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>Z</button>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />America</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Ammerpet</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Anakapalli</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Banglore</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Bapatla</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />BibiNagar</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Charlapalli</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Dindigal</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Eangland</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />pakistan</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Hyderabad</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Mumbai</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Nagaram</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Nacharam</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Anakappi</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />NarketPelli</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />America</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Ammerpet</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Anakapalli</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Banglore</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Bapatla</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />BibiNagar</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} alt="" />Charlapalli</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Dindigal</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: 'x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Eangland</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: 'space-evenly' }}><img
                                            style={{ color: '#270d44' }} />pakistan</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Hyderabad</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Mumbai</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Nagaram</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Nacharam</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />Anakappi</Button>
                                </div>
                                <div class="col-4">
                                    <Button class="form-control shadow"
                                        style={{ fontSize: ' x-small', justifyContent: ' space-evenly' }}><img
                                            style={{ color: '#270d44' }} />NarketPelli</Button>
                                </div>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    )
}

export default JobCards12;


// const Jobsalert=()=>{
//     return(
//         <div>
//             <div class="col-md-1 ">
// //                                 <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>R</button>
// //                             </div>
//         </div>
//     )
// }
// export default Jobsalert;