import React from "react";
import { Button } from "react-bootstrap";

const JobsBySkills = () => {

    return (
        <div>

            <div class="container blayer p-1">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-12 col-md-8 ">
                        <div class="row">
                            <div class="col-5"> </div>
                            <div class="col-2">
                                <p>Home Jobs</p>
                            </div>
                            <div class="col-4"> </div>
                        </div>
                        <div className="row" >
                            <div className="col-md-4 col-12 d-flex flex-row m-3 "
                                style={{ backgroundColor: 'white', height: '40px', width: '320px', borderRadius: '10px', marginLeft: '150px' }}>
                                <span class="px-1 mt-1"> <i class="fa-solid fa-location-dot"></i> </span>
                                <span class="px-5 mt-1 "><input
                                    className="w-100 dropdown-toggle"
                                    style={{ border: 'none', fontSize: 'small', width: '250px' }}
                                    type="search"


                                    placeholder="Enter location"
                                />
                                    {/* {browsejobss.map((blog) => setUserEnteredText(e.target.value)} */}
                                </span>
                                <span class="px-3"> <i class="fa-solid fa-caret-down"></i></span>
                            </div>
                            <div class="col-md-4 col-12 d-flex flex-row   m-3"
                                style={{ backgroundColor: 'white', height: '40px', width: '320px', borderRadius: '10px', marginLeft: '150px' }}>
                                <span class="px-1 mt-1"> <i class="fa-solid fa-location-dot"></i> </span>
                                <span class="px-5 mt-1 ">  <span class="px-5 mt-1 "><input
                                    className="w-100 dropdown-toggle"
                                    style={{ border: 'none', fontSize: 'small', width: '250px' }}
                                    type="search"

                                    placeholder="Enter location"
                                />
                                    {/* {browsejobss.map((blog) => setUserEnteredText(e.target.value)} */}
                                </span></span>
                                <span class="px-3"> <i class="fa-solid fa-caret-down"></i></span>
                            </div>
                        </div>
                        <div class=" col-md-2"> </div>
                        <div class="row m-1">
                            <div class="col-5 "> </div>
                            <div class="col-5">
                                <button style={{ backgroundColor: '#270d44', borderRadius: '5px', color: '#ffff' }}>Search</button>
                            </div>
                            <div class="col-4"> </div>

                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-3">
                <div className="row">


                    <div className="col-md-2"></div>
                    <div class="col-md-2 col-12">
                        <div class="d-grid form-control" id="allJobs">
                            <a href="jobmain">  <button type="button" style={{ color: 'black', fontSize: 'x-small', borderRadius: '2px' }}
                                class="btn  btn-block">All Jobs</button></a>
                        </div>


                        <div class="d-grid form-control " id="JobsByLocation">
                            <a href="jobcardsLLoc"> <button type="button" style={{ color: 'black', fontSize: 'x-small', border: 'none' }}
                                class="btn  btn-block">Jobs By location</button> </a>
                        </div>

                        <div class="d-grid form-control " id="JobsByCompany">
                            <a href="jobbycompany">  <button type="button" style={{ color: 'black', fontSize: 'x-small', border: 'none' }}
                                class="btn  btn-block">Jobs By Company</button> </a>
                        </div>

                        <div class="d-grid form-control" id="JobsByCategarey">
                            <a href="jobsbyCagegory"> <button type="button" style={{ color: 'black', fontSize: 'x-small', border: 'none' }}
                                class="btn  btn-block">Jobs By Categary</button> </a>
                        </div>

                        <div class="d-grid form-control " id="JobsByDesignation">
                            <a href="jobsbydesignation">  <button type="button" style={{ color: 'black', fontSize: 'x-small', border: 'none' }}
                                class="btn  btn-block">Jobs By Designation</button></a>
                        </div>


                        <div class="d-grid form-control " id="JobsBySkills" style={{ backgroundColor: '#270d44' }}>
                            <a href="jobsbyCagegory"> <button type="button" style={{ color: '#ffff', fontSize: 'x-small', border: 'none' }}
                                class="btn  btn-block">Jobs By Skills </button> </a>
                        </div>
                    </div>

                    <div className="col-md-6 row">

                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>A</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>B</button>
                        </div>

                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>C</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>D</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>E</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>F</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>G</button>
                        </div>


                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>H</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>I</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>J</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>K</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>L</button>
                        </div>

                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>M</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>N</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>O</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>P</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>Q</button>
                        </div>

                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>R</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>S</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>T</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>U</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>V</button>
                        </div>
                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>W</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>X</button>
                        </div>

                        <div class="col-md-1 ">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>Y</button>
                        </div>
                        <div class="col-md-1">
                            <button class="form-control" style={{ color: '#270d44', backgroundColor: '#fff' }}>Z</button>
                        </div>


                        {/* <div className="col-md-2"></div> */}
                        <div class="row">

                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Writing</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Dance Master</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Travelling</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Cooking</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Photography</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Vedio Making</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Designing</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Graphics</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Painting</Button>
                            </div>
                            
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Writing</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Dance Master</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Travelling</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Cooking</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Photography</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Vedio Making</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Designing</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Graphics</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Painting</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Writing</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Dance Master</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Travelling</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Cooking</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Photography</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Vedio Making</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Designing</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Graphics</Button>
                            </div>
                            <div class="col-3 m-2">
                                <Button className=" form-control shadow"
                                    style={{ fontSize: 'x-small', justifyContent: 'space-evenly', backgroundColor: 'white', color: '#270d44' }}><img
                                        style={{ color: '#270d44' }} alt="" />Painting</Button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}

export default JobsBySkills;